const allowedOrigins = [
    'https://fibecollection.com',
    'http://localhost:3500',
    'http://localhost:3000',
    'http://localhost:5000',
    'http://localhost:3001',
    'http://localhost:4200',
    'http://192.168.0.104:4200'
];

export default allowedOrigins;